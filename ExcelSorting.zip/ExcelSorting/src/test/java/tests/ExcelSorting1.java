package tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.collections4.iterators.SkippingIterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelSorting1 {
	public static final DataFormatter dataFormatter = new DataFormatter();
	public static final String FilePath = "C:/Users/bmahapathi/Desktop/new.xlsx";
	//public static XSSFWorkbook workbook;
	//public static XSSFSheet sheet;
	//public static Row row;

	

	public static void main(String[] args) throws IOException {
		//create a workbook from your file
	    FileInputStream excelFile = new FileInputStream(new File(FilePath));
	    Workbook originalWorkbook = new XSSFWorkbook(excelFile);
	    Sheet originalSheet = originalWorkbook.getSheetAt(0);

	    // Create a SortedMap<String, Row> where the key is the value of the first column
	    // This will automatically sort the rows
	    Map<String, Row> sortedRowsMap = new TreeMap<>();
	    Iterator<Row> rowIterator = originalSheet.rowIterator();
	    while(rowIterator.hasNext()) {
	        Row row = rowIterator.next();
	        if(row.getRowNum()==0) {
	        	continue;
	        }
	        sortedRowsMap.put(dataFormatter.formatCellValue(row.getCell(0)), row);
	        
	    }
	    System.out.println(sortedRowsMap);

	    // Create a new workbook
	    Workbook sortedWorkbook = new XSSFWorkbook();
	    Sheet sortedSheet = sortedWorkbook.createSheet(originalSheet.getSheetName());

	    // Copy all the sorted rows to the new workbook
	    int rowIndex = 0;
	    for(Row row : sortedRowsMap.values()) {
	        Row newRow = sortedSheet.createRow(rowIndex);
	        copyRowToRow(row, newRow);
	        rowIndex++;
	    }

	    // Write your new workbook to your file
	    try(FileOutputStream out = new FileOutputStream(FilePath)) {
	        sortedWorkbook.write(out);
	    } catch (FileNotFoundException ex) {
	        ex.printStackTrace();
	    }
	}


	// Utility method to copy rows
	private static void copyRowToRow(Row row, Row newRow) {
	    Iterator<Cell> cellIterator = row.cellIterator();
	    int cellIndex = 0;
	    while(cellIterator.hasNext()) {
	        Cell cell = cellIterator.next();
	        Cell newCell = newRow.createCell(cellIndex);
	        newCell.setCellValue(dataFormatter.formatCellValue(cell));
	        cellIndex++;
	    }
	}}
