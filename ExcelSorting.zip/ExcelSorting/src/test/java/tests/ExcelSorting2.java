package tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelSorting2 {
	public static final DataFormatter dataFormatter = new DataFormatter();
	public static final String FilePath = "C:/Users/bmahapathi/Desktop/new.xlsx";
	public static XSSFWorkbook workbook;
	public static XSSFSheet sheet;
	public static Row row;

	

	public static void main(String[] args) throws IOException {
		InputStream input = new FileInputStream(FilePath);
		workbook = new XSSFWorkbook(input);
		sheet = workbook.getSheetAt(0);
		//row = sheet.getRow(0);
		sortSheet(sheet, 0, 1);
		System.out.println("Done");
		finish();
		
	}

	

	private static void sortSheet(Sheet sheet, int column, int rowStart) {
		 boolean sorting = true;
		 int lastRow = sheet.getLastRowNum();
		 while (sorting) {
		    sorting = false;
		    for (Row row : sheet) {
		        if (row.getRowNum() < rowStart) continue;
		        if (lastRow == row.getRowNum()) break;
		        Row nextRow = sheet.getRow(row.getRowNum() + 1);
		        if (nextRow == null) continue;
		        double firstValue = row.getCell(column).getNumericCellValue() ;
		        double secondValue = nextRow.getCell(column).getNumericCellValue() ;
		        if (secondValue>firstValue) {                    
		            sheet.shiftRows(nextRow.getRowNum(), nextRow.getRowNum(), -1);
		           sheet.shiftRows(row.getRowNum(), row.getRowNum(), 1);
		            sorting = true;
		        }
		    }
		 }
		}

	

	private static void finish() {

		System.exit(0);
	}
}
